package com.example.projectknockknock;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.media.Image;
import android.media.ImageReader;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RatingBar;
import android.widget.TextView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.core.Tag;

import org.w3c.dom.Text;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class SubActivity extends AppCompatActivity implements Serializable {
    Button btnFeedback, btnReset, musicButton , testBtn;
    TextView musicIng, musicLink;
    ImageButton musicImageButton, ImageBtnFeedback, ImageBtnReset;
    View dialogView;

    List fileList = new ArrayList<>();
    ArrayAdapter adapter;
    static boolean calledAlready = false;

    static String song[] = new String[2];

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);

        Intent intent2 = getIntent();
        final String emotion = intent2.getStringExtra("emotion");


//        Intent intent = getIntent();
        Intent intent3 = new Intent(this.getIntent());
        final int heart = intent3.getIntExtra("heartBeat", 0);
        //intent.putIn

        //피드백임
        //btnFeedback = (Button) findViewById(R.id.btnFeedback);
        //btnReset = (Button) findViewById(R.id.btnReset);
        musicIng = (TextView) findViewById(R.id.musicIng);
        musicLink = (TextView) findViewById(R.id.musicLink);
        //musicButton = (Button) findViewById(R.id.musicButton);
        musicImageButton = (ImageButton) findViewById(R.id.musicImageButton);
        ImageBtnFeedback = (ImageButton) findViewById(R.id.ImagebtnFeedback);
        ImageBtnReset = (ImageButton) findViewById(R.id.ImagebtnReset);
/*
        testBtn = (Button) findViewById(R.id.testBtn);

        testBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                musicLink.setText(heart+emotion);
            }
        });
*/


        // 음악 실행 버튼 누르면 파이어베이스 기능 실행
        // 음악실행버튼 누르면 6가지 감정으로 분류해서 출력
        //  분노 혐오 두려움 행복 슬픔 놀람


        musicImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


/*
맥박수 측정.
0-70 > sad
70-80 > disgust
80-100 > happy, laugh, smile, talking
100-110 > surprise
110-130 > fear
130~ > angry
새로운 감정을 설정, 감정 범위 안에서 노래 랜덤으로 출력.
*/

                String a = "smile";
                //String emotion2 = emotion;

/*                if (emotion == "surprise") a = "surprise";
                if (emotion.equalsIgnoreCase("surprise")) a= "surprise";
                if (emotion.equals("surprise")) a= "surprise";
                if (emotion2 == "surprise") a= "surprsie";
                if (emotion2.equalsIgnoreCase("surprise")) a= "surprise";
                if (emotion2.equals("surprise")) a="surprise";

                if (emotion.compareTo("surprise") == 0) a="surprise";
                if (emotion2.compareTo("surprise") == 0) a="surprise";
                */


                if (heart != 0 ) {
                    if (heart > 0 && heart < 70) a = "sad";
                    if ( 70 <= heart && 80 > heart) a = "disgust";
                    if ( 80 <= heart && 100 > heart) a = "smile";
                    if ( 100 <= heart && 110 > heart) a = "surprise";
                    if ( 110 <= heart && 130 > heart ) a = "fear";
                    if ( 130 <= heart ) a = "angry";

                }

                //if (!emotion.equals(null)) {
                    else if (emotion.equals("surprise")) a = "surprise";
                    else if (emotion.equals("sad")) a = "sad";
                    else if (emotion.equals("disgust") || emotion.equals("neutral")) a = "disgust";
                    else if (emotion.equals("happy") || emotion.equals("laugh") || emotion.equals("smile") || emotion.equals("talking"))
                        a = "smile";
                    else if (emotion.equals("fear")) a = "fear";
                    else if (emotion.equals("angry")) a = "angry";
                //}






                //String emotion2 = emotion.toString();
/*                if (heart > 30 && heart < 70) {
                    a = "sad";
                } else if ( 70 <= heart && 80 > heart) {
                    a = "disgust";
                } else if ( 80 <= heart && 100 > heart) {
                    a = "smile";
                } else if ( 100 <= heart && 110 > heart) {
                    a = "surprise";
                } else if ( 110 <= heart && 130 > heart ) {
                    a = "fear";
                } else if ( 130 <= heart ){
                    a = "angry";
                }

                else if ( emotion == "sad") { a = "sad";
                } else if ( emotion == "disgust") { a= "disgust"; }
                else if (emotion == "neutral" ) {
                    a = "disgust";
                } else if ( emotion == "happy" || emotion == "laugh" || emotion == "smile" || emotion == "talking"){
                    a = "smile";
                } else if ( emotion == "fear" ) {
                    a = "fear";
                } else if ( emotion2 == "surprise"){
                    a = "surprise";
                } else if ( emotion == "angry") {
                    a = "angry";
                }

                */

                final FirebaseDatabase database;
                DatabaseReference myRefSad, myRefAngry, myRefDisgust, myRefFear, myRefSmile, myRefSurprise;

                // swtich 문으로, intent를 통해 넘어온 emotion의 정보에 따라 음악을 분류해서 출력.
                database = FirebaseDatabase.getInstance();
                myRefSad = database.getReference("sad"); // 감정에 따라서 바꿔줌
                myRefDisgust = database.getReference("disgust");
                myRefSmile = database.getReference("smile");
                myRefSurprise = database.getReference("surprise");
                myRefFear = database.getReference("fear");
                myRefAngry = database.getReference("angry");


                int number = 1;
                number = (int)(Math.random()*3); // 랜덤 함수
                String num = String.valueOf(number); // 넘겨줄 값



                switch (a) {
                    case "sad":
                        // *** sad 해당
                        myRefSad.child(num).addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                String myNames="";
                                int a= 0;

                                for (DataSnapshot myChild : dataSnapshot.getChildren()) {
                                    myNames = myNames + "\n\n" + myChild.getValue();
                                    //myNames = myNames + "\n\n" + myChild.child("1").getValue();
                                    //myNames = myNames + "\n\n" + myChild.limitToLast(1).getValue();

                                    song[a] = myNames;
                                    a++;
                                }
                                musicLink.setText(myNames);
                            }
                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                            }
                        });
                        break;


                    case "disgust":
                        // **** Digust 해당
                        myRefDisgust.child(num).addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                String myNames="";
                                int a= 0;
                                for (DataSnapshot myChild : dataSnapshot.getChildren()) {
                                    myNames = myNames + "\n\n" + myChild.getValue();
                                    song[a] = myNames;
                                    a++;
                                }
                                musicLink.setText(myNames);
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                            }
                        });
                        break;


                    case "smile":
                        // **** Smile 해당
                        myRefSmile.child(num).addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                String myNames="";
                                int a= 0;
                                for (DataSnapshot myChild : dataSnapshot.getChildren()) {
                                    myNames = myNames + "\n\n" + myChild.getValue();
                                    song[a] = myNames;
                                    a++;
                                }
                                musicLink.setText(myNames);
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                            }
                        });
                        break;


                    case "surprise":
                        // **** Surpirse해당
                        myRefSurprise.child(num).addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                String myNames="";
                                int a= 0;
                                for (DataSnapshot myChild : dataSnapshot.getChildren()) {
                                    myNames = myNames + "\n\n" + myChild.getValue();
                                    song[a] = myNames;
                                    a++;
                                }
                                musicLink.setText(myNames);
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                            }
                        });

                        break;


                    case "angry":
                        // **** Angry해당
                        myRefAngry.child(num).addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                String myNames="";
                                int a= 0;
                                for (DataSnapshot myChild : dataSnapshot.getChildren()) {
                                    myNames = myNames + "\n\n" + myChild.getValue();
                                    song[a] = myNames;
                                    a++;
                                }
                                musicLink.setText(myNames);
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                            }
                        });
                        break;


                    case "fear":
                        // **** Fear해당
                        myRefFear.child(num).addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                String myNames="";
                                int a= 0;
                                for (DataSnapshot myChild : dataSnapshot.getChildren()) {
                                    myNames = myNames + "\n\n" + myChild.getValue();
                                    song[a] = myNames;
                                    a++;
                                }
                                musicLink.setText(myNames);
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                            }
                        });
                        break;



                }


            }
/*
                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference myRef = database.getReference("test");

                myRef.setValue("Hello, World!");

                // Read from the database
                myRef.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        // This method is called once with the initial value and again
                        // whenever data at this location is updated.
                        String value = dataSnapshot.getValue(String.class);
                        //Log.d(TAG, "Value is: " + value);
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                        // Failed to read value
                        //Log.w(TAG, "Failed to read value.", error.toException());
                    }
                });

                DatabaseReference mdatabase;
                mdatabase = FirebaseDatabase.getInstance().getReference();
                musicLink.setText(mdatabase.toString());


            }

            */
        });



        ImageBtnFeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 피드백을 주기위한 버튼
                // Rating Bar사용

                // 곡정보를 넘겨줌
                Intent intent3 = new Intent(SubActivity.this, Rating.class);
                intent3.putExtra("singer", song[0]);
                intent3.putExtra("song", song[1]);
                startActivity(intent3);


            }
        });


        ImageBtnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 심박수를 재는 xml로 넘어감
                // 심박수에 따라 감정을 다시 분류하고 새로운 추천을 진행함

                Intent intent2 = new Intent(SubActivity.this, Heart.class);
                startActivity(intent2);

            }
        });
    }
}
